package gui;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class StudentRoutineView extends JFrame {
    DefaultTableModel routineModel;
    JTable routineTable;

    public StudentRoutineView(String department, int year, int semester) {
        setTitle("Your Routine");
        setSize(700, 400);
        setLayout(new BorderLayout());

        // Top: Search Panel
        JPanel topPanel = new JPanel();
        JTextField searchField = new JTextField(20);
        JButton searchBtn = new JButton("Search");
        topPanel.add(new JLabel("Search (day/subject/time):"));
        topPanel.add(searchField);
        topPanel.add(searchBtn);
        add(topPanel, BorderLayout.NORTH);

        // Center: Routine Table
        routineModel = new DefaultTableModel(new String[]{"Day", "Time", "Subject"}, 0);
        routineTable = new JTable(routineModel);
        add(new JScrollPane(routineTable), BorderLayout.CENTER);

        // Bottom: Report Problem
        JButton reportBtn = new JButton("Report a Problem");
        reportBtn.addActionListener(e -> reportProblem(department, year, semester));
        add(reportBtn, BorderLayout.SOUTH);

        searchBtn.addActionListener(e ->
                loadRoutine(department, year, semester, searchField.getText().trim()));

        loadRoutine(department, year, semester, null);
        setVisible(true);
    }

    private void loadRoutine(String dept, int year, int sem, String filter) {
        routineModel.setRowCount(0);
        try (Connection conn = DBConnection.getConnection()) {
            String sql = """
                SELECT day, time, subject FROM schedule
                WHERE department=? AND year=? AND semester=?""" +
                    (filter != null && !filter.isEmpty() ? """
                        AND (day LIKE ? OR time LIKE ? OR subject LIKE ?)
                        """ : "");

            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, dept);
            stmt.setInt(2, year);
            stmt.setInt(3, sem);
            if (filter != null && !filter.isEmpty()) {
                String like = "%" + filter + "%";
                stmt.setString(4, like);
                stmt.setString(5, like);
                stmt.setString(6, like);
            }

            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                routineModel.addRow(new Object[]{
                        rs.getString("day"),
                        rs.getString("time"),
                        rs.getString("subject")
                });
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void reportProblem(String dept, int year, int sem) {
        String issue = JOptionPane.showInputDialog(this, "Describe the issue:");
        if (issue == null || issue.isBlank()) return;

        try (Connection conn = DBConnection.getConnection()) {
            String sql = """
                INSERT INTO reports(department, year, semester, description)
                VALUES (?, ?, ?, ?)""";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, dept);
            stmt.setInt(2, year);
            stmt.setInt(3, sem);
            stmt.setString(4, issue);
            stmt.executeUpdate();
            JOptionPane.showMessageDialog(this, "Report submitted. Thank you!");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error submitting report.");
            e.printStackTrace();
        }
    }
}
