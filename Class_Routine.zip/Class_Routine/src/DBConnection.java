package gui;

import java.sql.*;

public class DBConnection {

    private static final String URL = "jdbc:mysql://localhost:3306/routine_db";
    private static final String USER = "root";      // usually 'root'
    private static final String PASSWORD = "abcd1234";

    static {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver"); // Newer driver class
            System.out.println("✅ MySQL JDBC driver loaded");
        } catch (ClassNotFoundException e) {
            System.out.println("❌ Failed to load MySQL driver: " + e.getMessage());
        }
    }

    public static Connection getConnection() {
        try {
            Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
            System.out.println("✅ Connected to MySQL database");
            return conn;
        } catch (SQLException e) {
            System.out.println("❌ DB Connection Failed: " + e.getMessage());
            return null;
        }
    }
}
