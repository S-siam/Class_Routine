package gui;

import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class RegisterPage extends JFrame {
    JTextField nameField = new JTextField(), emailField = new JTextField(),
            deptField = new JTextField(), yearField = new JTextField(),
            semField = new JTextField();
    JPasswordField passwordField = new JPasswordField();

    public RegisterPage() {
        setTitle("Register"); setSize(300,400); setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new GridLayout(7,2));
        add(new JLabel("Name:")); add(nameField);
        add(new JLabel("Email:")); add(emailField);
        add(new JLabel("Password:")); add(passwordField);
        add(new JLabel("Department:")); add(deptField);
        add(new JLabel("Year:")); add(yearField);
        add(new JLabel("Semester:")); add(semField);
        JButton btn = new JButton("Register");
        btn.addActionListener(e -> { register(); });
        add(btn);
        setVisible(true);
    }

    private void register() {
        try (Connection conn = DBConnection.getConnection()) {
            String sql = """
                INSERT INTO students(name,email,password,department,year,semester)
                VALUES(?,?,?,?,?,?)""";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, nameField.getText());
            stmt.setString(2, emailField.getText());
            stmt.setString(3, new String(passwordField.getPassword()));
            stmt.setString(4, deptField.getText());
            stmt.setInt(5, Integer.parseInt(yearField.getText()));
            stmt.setInt(6, Integer.parseInt(semField.getText()));
            stmt.executeUpdate();
            JOptionPane.showMessageDialog(this, "Registered!");
            dispose();
            new LoginPage();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }
}
