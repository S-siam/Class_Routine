package gui;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;
import java.time.LocalDate;
import java.util.Properties;

import org.jdatepicker.impl.*;

public class AdminPanel extends JFrame {
    private JTable scheduleTable, studentTable, reportTable;
    private DefaultTableModel scheduleModel, studentModel, reportModel;

    // Form fields
    private JTextField deptField, yearField, semField, dayField, timeField, subjectField;
    private JDatePickerImpl datePicker;

    public AdminPanel() {
        setTitle("Admin Panel");
        setSize(1100, 700);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        // Tabs
        JTabbedPane tabs = new JTabbedPane();
        tabs.addTab("Class Schedule", createClassPanel());
        tabs.addTab("Students", createStudentPanel());
        tabs.addTab("Reports", createReportPanel());

        setContentPane(tabs);

        loadClassData();
        loadStudentData();
        loadReports();

        setVisible(true);
    }

    private JPanel createClassPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createTitledBorder("Class Schedule"));

        // Form Panel
        JPanel formPanel = new JPanel(new GridLayout(2, 7, 5, 5));
        deptField = new JTextField();
        yearField = new JTextField();
        semField = new JTextField();
        dayField = new JTextField();
        timeField = new JTextField();
        subjectField = new JTextField();

        // Date Picker
        UtilDateModel model = new UtilDateModel();
        Properties p = new Properties();
        p.put("text.today", "Today");
        p.put("text.month", "Month");
        p.put("text.year", "Year");
        JDatePanelImpl datePanel = new JDatePanelImpl(model, p);
        datePicker = new JDatePickerImpl(datePanel, new DateLabelFormatter());

        formPanel.add(new JLabel("Department")); formPanel.add(new JLabel("Year"));
        formPanel.add(new JLabel("Semester")); formPanel.add(new JLabel("Day"));
        formPanel.add(new JLabel("Time")); formPanel.add(new JLabel("Subject"));
        formPanel.add(new JLabel("Date"));

        formPanel.add(deptField); formPanel.add(yearField);
        formPanel.add(semField); formPanel.add(dayField);
        formPanel.add(timeField); formPanel.add(subjectField);
        formPanel.add(datePicker);

        JButton addBtn = new JButton("Add Routine");
        addBtn.addActionListener(e -> addRoutine());

        // Table
        scheduleModel = new DefaultTableModel(new String[]{"ID", "Department", "Year", "Semester", "Day", "Time", "Subject", "Date"}, 0);
        scheduleTable = new JTable(scheduleModel);
        JScrollPane scrollPane = new JScrollPane(scheduleTable);

        // Buttons
        JButton editBtn = new JButton("Edit Selected");
        JButton deleteBtn = new JButton("Delete Selected");

        editBtn.addActionListener(e -> editSelectedClass());
        deleteBtn.addActionListener(e -> deleteSelectedClass());

        JPanel btnPanel = new JPanel();
        btnPanel.add(addBtn);
        btnPanel.add(editBtn);
        btnPanel.add(deleteBtn);

        panel.add(formPanel, BorderLayout.NORTH);
        panel.add(scrollPane, BorderLayout.CENTER);
        panel.add(btnPanel, BorderLayout.SOUTH);

        return panel;
    }

    private JPanel createStudentPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createTitledBorder("Registered Students"));

        studentModel = new DefaultTableModel(new String[]{"ID", "Name", "Email", "Department", "Year", "Semester"}, 0);
        studentTable = new JTable(studentModel);
        JScrollPane scrollPane = new JScrollPane(studentTable);

        JButton deleteBtn = new JButton("Delete Selected");
        deleteBtn.addActionListener(e -> deleteSelectedStudent());

        panel.add(scrollPane, BorderLayout.CENTER);
        panel.add(deleteBtn, BorderLayout.SOUTH);
        return panel;
    }

    private JPanel createReportPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createTitledBorder("Problem Reports"));

        reportModel = new DefaultTableModel(new String[]{"ID", "Department", "Year", "Semester", "Description", "Time"}, 0);
        reportTable = new JTable(reportModel);
        JScrollPane scrollPane = new JScrollPane(reportTable);

        panel.add(scrollPane, BorderLayout.CENTER);
        return panel;
    }

    private void loadClassData() {
        scheduleModel.setRowCount(0);
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "SELECT * FROM schedule";
            ResultSet rs = conn.createStatement().executeQuery(sql);
            while (rs.next()) {
                scheduleModel.addRow(new Object[]{
                        rs.getInt("id"),
                        rs.getString("department"),
                        rs.getInt("year"),
                        rs.getInt("semester"),
                        rs.getString("day"),
                        rs.getString("time"),
                        rs.getString("subject"),
                        rs.getDate("date")
                });
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void loadStudentData() {
        studentModel.setRowCount(0);
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "SELECT * FROM students";
            ResultSet rs = conn.createStatement().executeQuery(sql);
            while (rs.next()) {
                studentModel.addRow(new Object[]{
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getString("email"),
                        rs.getString("department"),
                        rs.getInt("year"),
                        rs.getInt("semester")
                });
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void loadReports() {
        reportModel.setRowCount(0);
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "SELECT * FROM reports ORDER BY timestamp DESC";
            ResultSet rs = conn.createStatement().executeQuery(sql);
            while (rs.next()) {
                reportModel.addRow(new Object[]{
                        rs.getInt("id"),
                        rs.getString("department"),
                        rs.getInt("year"),
                        rs.getInt("semester"),
                        rs.getString("description"),
                        rs.getTimestamp("timestamp")
                });
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void addRoutine() {
        java.util.Date selectedDate = (java.util.Date) datePicker.getModel().getValue();
        if (selectedDate == null) {
            JOptionPane.showMessageDialog(this, "Please select a valid date.");
            return;
        }
        try (Connection conn = DBConnection.getConnection()) {
            String sql = """
                INSERT INTO schedule(department, year, semester, day, time, subject, date)
                VALUES (?, ?, ?, ?, ?, ?, ?)""";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, deptField.getText());
            stmt.setInt(2, Integer.parseInt(yearField.getText()));
            stmt.setInt(3, Integer.parseInt(semField.getText()));
            stmt.setString(4, dayField.getText());
            stmt.setString(5, timeField.getText());
            stmt.setString(6, subjectField.getText());
            stmt.setDate(7, new java.sql.Date(selectedDate.getTime()));
            stmt.executeUpdate();
            JOptionPane.showMessageDialog(this, "Routine added!");
            loadClassData();
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }

    private void editSelectedClass() {
        int row = scheduleTable.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Select a class to edit.");
            return;
        }

        int id = (int) scheduleModel.getValueAt(row, 0);
        String dept = JOptionPane.showInputDialog("Department:", scheduleModel.getValueAt(row, 1));
        String year = JOptionPane.showInputDialog("Year:", scheduleModel.getValueAt(row, 2));
        String sem = JOptionPane.showInputDialog("Semester:", scheduleModel.getValueAt(row, 3));
        String day = JOptionPane.showInputDialog("Day:", scheduleModel.getValueAt(row, 4));
        String time = JOptionPane.showInputDialog("Time:", scheduleModel.getValueAt(row, 5));
        String subject = JOptionPane.showInputDialog("Subject:", scheduleModel.getValueAt(row, 6));
        String dateStr = JOptionPane.showInputDialog("Date (YYYY-MM-DD):", scheduleModel.getValueAt(row, 7));

        java.sql.Date sqlDate;
        try {
            sqlDate = java.sql.Date.valueOf(dateStr.trim());
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Invalid date format.");
            return;
        }

        try (Connection conn = DBConnection.getConnection()) {
            String sql = """
                UPDATE schedule SET department=?, year=?, semester=?, day=?, time=?, subject=?, date=?
                WHERE id=?""";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, dept);
            stmt.setInt(2, Integer.parseInt(year));
            stmt.setInt(3, Integer.parseInt(sem));
            stmt.setString(4, day);
            stmt.setString(5, time);
            stmt.setString(6, subject);
            stmt.setDate(7, sqlDate);
            stmt.setInt(8, id);
            stmt.executeUpdate();
            JOptionPane.showMessageDialog(this, "Class updated");
            loadClassData();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }

    private void deleteSelectedClass() {
        int row = scheduleTable.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Select a class to delete.");
            return;
        }

        int id = (int) scheduleModel.getValueAt(row, 0);
        int confirm = JOptionPane.showConfirmDialog(this, "Delete this class?", "Confirm", JOptionPane.YES_NO_OPTION);
        if (confirm != JOptionPane.YES_OPTION) return;

        try (Connection conn = DBConnection.getConnection()) {
            String sql = "DELETE FROM schedule WHERE id=?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);
            stmt.executeUpdate();
            JOptionPane.showMessageDialog(this, "Class deleted");
            loadClassData();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }

    private void deleteSelectedStudent() {
        int row = studentTable.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Select a student to delete.");
            return;
        }

        int id = (int) studentModel.getValueAt(row, 0);
        int confirm = JOptionPane.showConfirmDialog(this, "Delete this student?", "Confirm", JOptionPane.YES_NO_OPTION);
        if (confirm != JOptionPane.YES_OPTION) return;

        try (Connection conn = DBConnection.getConnection()) {
            String sql = "DELETE FROM students WHERE id=?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);
            stmt.executeUpdate();
            JOptionPane.showMessageDialog(this, "Student deleted");
            loadStudentData();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }

    // Helper class for formatting the date picker text field
    static class DateLabelFormatter extends JFormattedTextField.AbstractFormatter {
        @Override
        public Object stringToValue(String text) {
            return java.sql.Date.valueOf(text);
        }

        @Override
        public String valueToString(Object value) {
            if (value != null) {
                java.util.Calendar cal = (java.util.Calendar) value;
                java.sql.Date date = new java.sql.Date(cal.getTimeInMillis());
                return date.toString();
            }
            return "";
        }
    }
}
