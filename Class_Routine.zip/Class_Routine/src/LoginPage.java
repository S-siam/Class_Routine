package gui;

import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class LoginPage extends JFrame {
    JTextField emailField = new JTextField();
    JPasswordField passwordField = new JPasswordField();

    public LoginPage() {
        setTitle("Login"); setSize(300,200); setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new GridLayout(3,2));
        add(new JLabel("Email:")); add(emailField);
        add(new JLabel("Password:")); add(passwordField);

        JButton loginBtn = new JButton("Login");
        loginBtn.addActionListener(e -> login());
        JButton regBtn = new JButton("Register");
        regBtn.addActionListener(e -> { dispose(); new RegisterPage(); });

        add(loginBtn); add(regBtn);
        setVisible(true);
    }

    private void login() {
        String email = emailField.getText();
        String password = new String(passwordField.getPassword());

        if (email.equals("admin@ju.ac.bd") && password.equals("admin123")) {
            JOptionPane.showMessageDialog(this, "Admin Access");
            dispose();
            new AdminPanel();
            return;
        }

        try (Connection conn = DBConnection.getConnection()) {
            String sql = "SELECT * FROM students WHERE email=? AND password=?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, email);
            stmt.setString(2, password);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                JOptionPane.showMessageDialog(this, "Welcome!");
                dispose();
                new StudentRoutineView(
                        rs.getString("department"),
                        rs.getInt("year"),
                        rs.getInt("semester")
                );
            } else {
                JOptionPane.showMessageDialog(this, "Invalid credentials");
            }
        } catch (Exception ex) { ex.printStackTrace(); }
    }
}
